$().eq(index) reduces the collection to the element at that index.  If the index is negative, it will go backwards.

