/* global af*/
(function($ui){
    "use strict";
    function fadeTransition (oldDiv, currDiv, back) {
        /*jshint validthis:true */
        var that = this;
        if (back) {
            currDiv.style.zIndex = 1;
            oldDiv.style.zIndex = 2;
            that.clearAnimations(currDiv);
            that.css3animate(oldDiv, {
                x: "0%",
                time: $ui.transitionTime,
                opacity: 0.1,
                complete: function(canceled) {
                    if(canceled) {
                        that.finishTransition(oldDiv, currDiv);
                        return;
                    }

                    that.css3animate(oldDiv, {
                        x: "-100%",
                        opacity: 1,
                        complete: function() {
                            that.finishTransition(oldDiv);
                        }

                    });
                    currDiv.style.zIndex = 2;
                    oldDiv.style.zIndex = 1;
                }
            });
        } else {
            oldDiv.style.zIndex = 1;
            currDiv.style.zIndex = 2;
            currDiv.style.opacity = 0;
            that.css3animate(currDiv, {
                x: "0%",
                opacity: 0.1,
                complete: function() {
                    that.css3animate(currDiv, {
                        x: "0%",
                        time: $ui.transitionTime,
                        opacity: 1,
                        complete:function(canceled){
                            if(canceled) {
                                that.finishTransition(oldDiv, currDiv);
                                return;
                            }

                            that.clearAnimations(currDiv);
                            that.css3animate(oldDiv, {
                                x: "-100%",
                                y: 0,
                                complete: function() {
                                    that.finishTransition(oldDiv);
                                }
                            });
                        }
                    });
                }
            });
        }
    }
    $ui.availableTransitions.fade = fadeTransition;
})(af.ui);