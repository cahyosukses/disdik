
		<ul class="breadcrumb wellwhite">
			<li><a href="<?php echo base_URL()?>">Beranda</a> <span class="divider">/</span></li>			
			<li>Invalid Post ID</li>
			
		</ul>
		
		<div class='alert alert-error'>Invalid ID.</div>
