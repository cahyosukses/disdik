
		<ul class="breadcrumb wellwhite">
			<li><a href="<?php echo base_URL()?>">Beranda</a> <span class="divider">/</span></li>
			<li>Data dan Informasi <span class="divider">/</span></li>
			<li><?php echo $data_informasi->judul?></li>
			
		</ul>
		
		 <div class="span12 wellwhite" style="margin-left: 0px">
		  <legend><?php echo $data_informasi->judul?></legend>
		  
		  <p><?php echo $data_informasi->isi?></p>

		</div>
<!--/span-->